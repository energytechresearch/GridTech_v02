import { generateText } from "ai"

export const maxDuration = 30

export async function POST(req: Request) {
  try {
    const { messages, dataScope } = await req.json()

    if (!messages || !Array.isArray(messages)) {
      return Response.json({ error: "Invalid messages format" }, { status: 400 })
    }

    // Convert messages to a format suitable for the AI model
    const lastUserMessage = messages.filter((m: any) => m.role === "user").pop()?.content || ""

    // Create context-aware system prompt
    const systemContext = `You are an AI assistant for GridTech, a portfolio management platform for grid technology projects. 
You help users analyze and understand their portfolio data including:
- Technology pilots and their status
- Risk assessments and scores  
- Technology library and specifications
- Market intelligence and trends
- Project intake and portfolio management

Current data scope: ${dataScope || "full-portfolio"}

Provide concise, actionable insights based on the user's questions. When referencing data, use realistic examples that would be relevant to grid technology projects (e.g., hydrogen storage, smart grid systems, renewable integration, etc.).`

    const prompt = `${systemContext}\n\nUser question: ${lastUserMessage}`

    // Generate response using AI SDK
    const { text } = await generateText({
      model: "openai/gpt-5-mini",
      prompt,
      maxOutputTokens: 1000,
      temperature: 0.7,
    })

    return Response.json({ reply: text })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return Response.json({ error: "Failed to generate response" }, { status: 500 })
  }
}
