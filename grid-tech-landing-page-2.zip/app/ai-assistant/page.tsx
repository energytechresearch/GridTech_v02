"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

type Message = {
  role: "user" | "assistant"
  content: string
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [dataScope, setDataScope] = useState("full-portfolio")

  const suggestions = [
    "Show me active pilots with high risk scores",
    "Summarize hydrogen storage technologies",
    "What technologies moved to operations this quarter?",
  ]

  async function handleSend(e: React.FormEvent) {
    e.preventDefault()
    if (!input.trim() || loading) return

    const newMessage: Message = { role: "user", content: input }
    const updated = [...messages, newMessage]

    setMessages(updated)
    setInput("")
    setLoading(true)

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updated,
          dataScope,
        }),
      })

      if (!res.ok) {
        throw new Error("Failed to get response")
      }

      const data = await res.json()

      setMessages([...updated, { role: "assistant", content: data.reply || "No response received." }])
    } catch (err) {
      console.error("[v0] Chat error:", err)
      setMessages([...updated, { role: "assistant", content: "⚠️ Error getting response. Please try again." }])
    } finally {
      setLoading(false)
    }
  }

  function handleSuggestionClick(suggestion: string) {
    setInput(suggestion)
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Left Sidebar */}
      <aside className="w-64 border-r border-border bg-card p-4">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-2">GridTech AI</h2>
          <p className="text-sm text-muted-foreground">Portfolio Intelligence</p>
        </div>
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-foreground">Conversations</h3>
          <p className="text-xs text-muted-foreground">Conversation history coming soon</p>
        </div>
      </aside>

      {/* Main Chat Panel */}
      <main className="flex flex-col flex-1">
        {/* Header */}
        <header className="border-b border-border bg-card p-4">
          <h1 className="text-lg font-semibold text-foreground">Portfolio Intelligence Chat</h1>
          <p className="text-sm text-muted-foreground">Ask questions about pilots, technologies, and risks.</p>
        </header>

        {/* Chat Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex items-center justify-center h-full">
              <div className="text-center max-w-md">
                <h2 className="text-xl font-semibold text-foreground mb-2">Welcome to GridTech AI</h2>
                <p className="text-muted-foreground mb-6">
                  Ask questions about your portfolio, technologies, pilots, and market intelligence.
                </p>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-foreground">Try asking:</p>
                  {suggestions.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => handleSuggestionClick(s)}
                      className="block w-full text-left px-4 py-2 text-sm border border-border rounded-lg hover:bg-muted transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              <Card
                className={`p-4 max-w-xl ${msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"}`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
              </Card>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <Card className="p-4 bg-muted">
                <p className="text-sm text-muted-foreground">Analyzing portfolio data…</p>
              </Card>
            </div>
          )}
        </div>

        {/* Suggested Prompts - shown when there are messages */}
        {messages.length > 0 && (
          <div className="border-t border-border bg-card px-4 py-3">
            <div className="flex gap-2 flex-wrap">
              {suggestions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => handleSuggestionClick(s)}
                  disabled={loading}
                  className="px-3 py-1.5 text-sm border border-border rounded-md hover:bg-muted transition-colors disabled:opacity-50"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Bar */}
        <form onSubmit={handleSend} className="border-t border-border bg-card p-4">
          <div className="flex gap-3 max-w-4xl mx-auto">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a question about your portfolio…"
              disabled={loading}
              className="flex-1 border border-border rounded-lg px-4 py-3 bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"
            />
            <Button type="submit" disabled={loading || !input.trim()} size="lg">
              Send
            </Button>
          </div>
        </form>
      </main>

      {/* Right Context Panel */}
      <aside className="w-72 border-l border-border bg-card p-4 space-y-6">
        <div>
          <h3 className="text-sm font-semibold text-foreground mb-4">Context</h3>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">Data Scope</label>
              <select
                value={dataScope}
                onChange={(e) => setDataScope(e.target.value)}
                className="w-full border border-border rounded-md px-3 py-2 bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="full-portfolio">Full Portfolio</option>
                <option value="pilots-only">Pilots Only</option>
                <option value="technology-library">Technology Library</option>
                <option value="risk-register">Risk Register</option>
              </select>
            </div>

            <div>
              <h4 className="text-sm font-medium text-foreground mb-2">Sources Used</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                  Technologies
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                  Pilots
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                  Risk Register
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                  Market Intelligence
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            Role-based access enforced. Sensitive fields are hidden based on your permissions.
          </p>
        </div>

        <div className="border-t border-border pt-4">
          <h4 className="text-sm font-medium text-foreground mb-2">About</h4>
          <p className="text-xs text-muted-foreground leading-relaxed">
            This AI assistant uses your portfolio data to answer questions and provide insights about technologies,
            pilots, and market trends.
          </p>
        </div>
      </aside>
    </div>
  )
}
